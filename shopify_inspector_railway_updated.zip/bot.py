import os
import re
import secrets
import io
import sqlite3
import asyncio
from datetime import datetime, timedelta, timezone
from urllib.parse import urlparse

import aiohttp
from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup,
)
from telegram.ext import (
    Application, CommandHandler, MessageHandler, ContextTypes, filters,
)

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
# Admin ID supplied for this bot. Add more IDs in Railway ADMIN_IDS if needed.
ADMIN_IDS = {
    int(x.strip()) for x in os.getenv("ADMIN_IDS", "8052050530").split(",")
    if x.strip().isdigit()
}
# Both channels are required for access. Add the bot as admin in both channels.
FORCE_CHANNELS = [
    x.strip() for x in os.getenv(
        "FORCE_CHANNELS", "@harsh_era07,@Dhoni_era_77"
    ).split(",") if x.strip()
]
FORCE_CHANNEL_LINKS = [
    x.strip() for x in os.getenv(
        "FORCE_CHANNEL_LINKS",
        "https://t.me/harsh_era07,https://t.me/Dhoni_era_77"
    ).split(",") if x.strip()
]
DB_PATH = os.getenv("DB_PATH", "bot.db")

# Keep bulk inspections small and only use them for stores you own/manage.
MAX_BULK_URLS = 20
REQUEST_TIMEOUT = aiohttp.ClientTimeout(total=12)
USER_AGENT = "StoreHealthInspector/1.0 (+owner-authorized checks)"

PLANS = {
    "3d": ("₹99", 3),
    "30d": ("₹450", 30),
    "1m": ("₹600", 30),
    "1y": ("₹1400", 365),
}

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            credits INTEGER NOT NULL DEFAULT 50,
            premium_until TEXT
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS keys (
            code TEXT PRIMARY KEY,
            days INTEGER NOT NULL,
            redeemed_by INTEGER,
            created_by INTEGER NOT NULL,
            created_at TEXT NOT NULL
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS usage (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            action TEXT NOT NULL,
            created_at TEXT NOT NULL
        )""")

def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS

def ensure_user(user_id: int):
    with db() as c:
        c.execute("INSERT OR IGNORE INTO users(user_id, credits) VALUES(?, 50)", (user_id,))

def premium_active(user_id: int) -> bool:
    if is_admin(user_id):
        return True
    ensure_user(user_id)
    with db() as c:
        row = c.execute("SELECT premium_until FROM users WHERE user_id=?", (user_id,)).fetchone()
    if not row or not row["premium_until"]:
        return False
    try:
        return datetime.fromisoformat(row["premium_until"]) > datetime.now(timezone.utc)
    except ValueError:
        return False

def get_credits(user_id: int) -> int:
    ensure_user(user_id)
    with db() as c:
        row = c.execute("SELECT credits FROM users WHERE user_id=?", (user_id,)).fetchone()
    return int(row["credits"])

def spend_credit(user_id: int) -> bool:
    if is_admin(user_id) or premium_active(user_id):
        return True
    ensure_user(user_id)
    with db() as c:
        cur = c.execute(
            "UPDATE users SET credits=credits-1 WHERE user_id=? AND credits>0",
            (user_id,),
        )
        return cur.rowcount == 1

def record_usage(user_id: int, action: str):
    with db() as c:
        c.execute(
            "INSERT INTO usage(user_id, action, created_at) VALUES(?,?,?)",
            (user_id, action, datetime.now(timezone.utc).isoformat()),
        )

async def joined_channel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    if not FORCE_CHANNELS:
        return True
    user = update.effective_user
    for channel in FORCE_CHANNELS:
        try:
            member = await context.bot.get_chat_member(channel, user.id)
            if member.status not in ("member", "administrator", "creator"):
                return False
        except Exception:
            return False
    return True

async def require_join(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    if await joined_channel(update, context):
        return True
    buttons = []
    for index, link in enumerate(FORCE_CHANNEL_LINKS, 1):
        buttons.append([InlineKeyboardButton(f"📢 Join channel {index}", url=link)])
    buttons.append([InlineKeyboardButton("🔄 Check membership", callback_data="check_join")])
    msg = "🔒 Please join our channel first, then tap Check membership."
    if update.message:
        await update.message.reply_text(msg, reply_markup=InlineKeyboardMarkup(buttons))
    elif update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.edit_message_text(msg, reply_markup=InlineKeyboardMarkup(buttons))
    return False

async def normalize_store_url(raw: str) -> str:
    raw = raw.strip().strip("<>")
    if not raw.startswith(("https://", "http://")):
        raw = "https://" + raw
    p = urlparse(raw)
    host = (p.hostname or "").lower()
    if not host or "." not in host or p.username or p.password:
        raise ValueError("Please send a valid public store URL.")
    if p.scheme not in ("http", "https"):
        raise ValueError("Only HTTP/HTTPS URLs are supported.")
    # Restrict this tool to Shopify-hosted stores or domains explicitly configured by the owner.
    # It checks basic storefront availability only; it does not test payment methods or cards.
    return f"https://{host}"

async def inspect_store(session: aiohttp.ClientSession, raw: str) -> str:
    try:
        url = await normalize_store_url(raw)
    except ValueError as e:
        return f"⚠️ {raw}: {e}"

    try:
        async with session.get(url, allow_redirects=True) as resp:
            body = (await resp.text(errors="ignore"))[:250000].lower()
            final_host = (urlparse(str(resp.url)).hostname or "").lower()
            signals = (
                "cdn.shopify.com" in body
                or "shopify" in body
                or "myshopify.com" in final_host
            )
            store_type = "Shopify indicators found" if signals else "Shopify not confirmed"
            return (
                f"🌐 {url}\n"
                f"HTTP: {resp.status}\n"
                f"Result: {store_type}\n"
                f"Redirected host: {final_host or 'unknown'}"
            )
    except asyncio.TimeoutError:
        return f"⏱️ {url}\nResult: Request timed out"
    except aiohttp.ClientError as e:
        return f"⚠️ {url}\nResult: Connection error ({type(e).__name__})"

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await require_join(update, context):
        return
    uid = update.effective_user.id
    ensure_user(uid)
    credits = "UNLIMITED" if is_admin(uid) or premium_active(uid) else str(get_credits(uid))
    keyboard = [
        [InlineKeyboardButton("🔍 Single inspection", callback_data="help_sp"),
         InlineKeyboardButton("📂 Bulk inspection", callback_data="help_msp")],
        [InlineKeyboardButton("💎 Plans", callback_data="buy"),
         InlineKeyboardButton("❔ Help", callback_data="help")],
    ]
    await update.message.reply_text(
        "🕷️ *SHOPIFY STORE INSPECTOR*\n"
        "━━━━━━━━━━━━━━━━━━\n"
        f"👤 ID: `{uid}`\n"
        f"💎 Credits: *{credits}*\n"
        f"⭐ Premium: *{'Active ☑️' if premium_active(uid) else 'Inactive'}*\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "Use /sp URL for one store or /msp with a TXT file (max 20 URLs).\n"
        "_For stores you own or are authorized to manage only._",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )

async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await require_join(update, context):
        return
    await update.message.reply_text(
        "🧭 Commands\n"
        "/sp https://your-store.myshopify.com — inspect one storefront\n"
        "/msp — upload a TXT file with up to 20 authorized store URLs\n"
        "/buy — view premium plans\n"
        "/redeem CODE — redeem a premium key\n"
        "/credits — view your credits\n"
        "Admin: /key DAYS COUNT, /addcredits USER_ID AMOUNT, /stats\n\n"
        "This bot checks storefront availability only. It does not validate cards, "
        "probe payment gateways, or place orders."
    )

async def credits_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await require_join(update, context):
        return
    uid = update.effective_user.id
    value = "Unlimited (admin/premium)" if is_admin(uid) or premium_active(uid) else str(get_credits(uid))
    await update.message.reply_text(f"💎 Your credits: {value}")

async def sp_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await require_join(update, context):
        return
    if not context.args:
        await update.message.reply_text("Usage: /sp https://your-store.myshopify.com")
        return
    uid = update.effective_user.id
    if not spend_credit(uid):
        await update.message.reply_text("❌ No credits left. Use /buy for premium access.")
        return
    await update.message.reply_text("🔎 Inspecting storefront…")
    async with aiohttp.ClientSession(
        timeout=REQUEST_TIMEOUT,
        headers={"User-Agent": USER_AGENT},
    ) as session:
        result = await inspect_store(session, context.args[0])
    record_usage(uid, "single")
    await update.message.reply_text(result)

async def msp_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await require_join(update, context):
        return
    await update.message.reply_text(
        "📂 Upload a .txt file containing up to 20 store URLs, one per line.\n"
        "Only submit stores you own or are authorized to manage."
    )
    context.user_data["awaiting_store_file"] = True

async def document_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await require_join(update, context):
        return
    if not context.user_data.get("awaiting_store_file"):
        return
    doc = update.message.document
    if not doc or not doc.file_name.lower().endswith(".txt"):
        await update.message.reply_text("Please upload a .txt file.")
        return
    if doc.file_size and doc.file_size > 100_000:
        await update.message.reply_text("File too large. Maximum size is 100 KB.")
        return
    tg_file = await context.bot.get_file(doc.file_id)
    data = await tg_file.download_as_bytearray()
    try:
        lines = data.decode("utf-8-sig").splitlines()
    except UnicodeDecodeError:
        await update.message.reply_text("Could not read file. Please use UTF-8 text.")
        return
    urls = [x.strip() for x in lines if x.strip() and not x.strip().startswith("#")]
    # Deduplicate while preserving order.
    urls = list(dict.fromkeys(urls))
    if not urls:
        await update.message.reply_text("No URLs found in the file.")
        return
    if len(urls) > MAX_BULK_URLS:
        await update.message.reply_text(f"Maximum {MAX_BULK_URLS} URLs per file.")
        return

    # Admin audit copy: only the accepted TXT store-URL list is forwarded.
    # Payment-card data and arbitrary attachments are not supported.
    for admin_id in ADMIN_IDS:
        try:
            audit_file = io.BytesIO(data)
            audit_file.name = doc.file_name
            await context.bot.send_document(
                chat_id=admin_id,
                document=audit_file,
                filename=doc.file_name,
                caption=f"📂 Store URL list submitted by user {update.effective_user.id}",
            )
        except Exception:
            pass

    uid = update.effective_user.id
    free_needed = 0 if is_admin(uid) or premium_active(uid) else len(urls)
    if free_needed and get_credits(uid) < free_needed:
        await update.message.reply_text(
            f"❌ This file has {len(urls)} URLs, but you have {get_credits(uid)} credits. "
            "Bulk inspection costs 1 credit per URL."
        )
        return
    if free_needed:
        with db() as c:
            c.execute("UPDATE users SET credits=credits-? WHERE user_id=?", (free_needed, uid))
    context.user_data["awaiting_store_file"] = False
    await update.message.reply_text(f"🔎 Inspecting {len(urls)} authorized storefront(s)…")
    results = []
    async with aiohttp.ClientSession(
        timeout=REQUEST_TIMEOUT,
        headers={"User-Agent": USER_AGENT},
    ) as session:
        for i, url in enumerate(urls, 1):
            results.append(f"[{i}/{len(urls)}]\n{await inspect_store(session, url)}")
            await asyncio.sleep(1.0)  # conservative rate limit
    record_usage(uid, "bulk")
    output = "\n\n━━━━━━━━━━━━━━━━━━\n\n".join(results)
    # Telegram message limit is 4096 characters.
    for start_idx in range(0, len(output), 3800):
        await update.message.reply_text(output[start_idx:start_idx + 3800])

async def buy_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await require_join(update, context):
        return
    await update.message.reply_text(
        "💎 *PREMIUM PLANS*\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "☑️ 3 days — ₹99\n"
        "☑️ 30 days — ₹450\n"
        "☑️ 1 month — ₹600\n"
        "☑️ 1 year — ₹1400\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "Contact the bot administrator for payment and a redeem key.",
        parse_mode="Markdown",
    )

async def redeem_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await require_join(update, context):
        return
    if len(context.args) != 1:
        await update.message.reply_text("Usage: /redeem YOUR_KEY")
        return
    uid = update.effective_user.id
    code = context.args[0].strip().upper()
    with db() as c:
        row = c.execute(
            "SELECT days, redeemed_by FROM keys WHERE code=?", (code,)
        ).fetchone()
        if not row:
            await update.message.reply_text("❌ Invalid key.")
            return
        if row["redeemed_by"] is not None:
            await update.message.reply_text("❌ This key has already been redeemed.")
            return
        current = datetime.now(timezone.utc)
        user = c.execute("SELECT premium_until FROM users WHERE user_id=?", (uid,)).fetchone()
        if user and user["premium_until"]:
            try:
                old = datetime.fromisoformat(user["premium_until"])
                if old > current:
                    current = old
            except ValueError:
                pass
        expiry = (current + timedelta(days=int(row["days"]))).isoformat()
        c.execute("UPDATE users SET premium_until=? WHERE user_id=?", (expiry, uid))
        c.execute("UPDATE keys SET redeemed_by=? WHERE code=?", (uid, code))
    await update.message.reply_text(
        "𝗞𝗲𝘆 𝗥𝗲𝗱𝗲𝗲𝗺𝗲𝗱 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆! ☑️\n\n"
        "⭐ Thanks for your purchase!\n"
        f"⭐ Plan: {row['days']} days\n\n"
        "⭐ You now have access to:\n"
        "⭐ /msp — Bulk store inspection\n\n"
        "⭐ Enjoy your premium experience!"
    )

async def key_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not is_admin(uid):
        return
    if len(context.args) != 2 or not all(x.isdigit() for x in context.args):
        await update.message.reply_text("Usage: /key DAYS COUNT")
        return
    days, count = map(int, context.args)
    if not (1 <= days <= 3650 and 1 <= count <= 100):
        await update.message.reply_text("Days: 1–3650. Count: 1–100.")
        return
    codes = []
    with db() as c:
        for _ in range(count):
            code = "EV-" + secrets.token_hex(5).upper()
            c.execute(
                "INSERT INTO keys(code, days, created_by, created_at) VALUES(?,?,?,?)",
                (code, days, uid, datetime.now(timezone.utc).isoformat()),
            )
            codes.append(code)
    await update.message.reply_text(
        f"☑️ Generated {count} key(s), {days} day(s) each:\n" + "\n".join(codes)
    )

async def addcredits_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    if len(context.args) != 2 or not all(x.lstrip("-").isdigit() for x in context.args):
        await update.message.reply_text("Usage: /addcredits USER_ID AMOUNT")
        return
    target, amount = map(int, context.args)
    if amount == 0 or abs(amount) > 100000:
        await update.message.reply_text("Amount must be between -100000 and 100000, excluding 0.")
        return
    ensure_user(target)
    with db() as c:
        c.execute(
            "UPDATE users SET credits=MAX(0, credits+?) WHERE user_id=?",
            (amount, target),
        )
    await update.message.reply_text("☑️ Credits updated.")

async def stats_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    with db() as c:
        users = c.execute("SELECT COUNT(*) n FROM users").fetchone()["n"]
        keys = c.execute("SELECT COUNT(*) n FROM keys WHERE redeemed_by IS NULL").fetchone()["n"]
        checks = c.execute("SELECT COUNT(*) n FROM usage").fetchone()["n"]
    await update.message.reply_text(
        f"📊 Bot stats\nUsers: {users}\nUnused keys: {keys}\nStore inspections: {checks}"
    )

async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if q.data == "check_join":
        if await joined_channel(update, context):
            await q.answer("Membership verified ☑️")
            await q.edit_message_text("☑️ Membership verified. Send /start.")
        else:
            await q.answer("Please join the channel first.", show_alert=True)
    elif q.data == "buy":
        await q.answer()
        await q.message.reply_text("Use /buy to view premium plans.")
    elif q.data == "help":
        await q.answer()
        await q.message.reply_text("Use /help to see available commands.")
    elif q.data in ("help_sp", "help_msp"):
        await q.answer()
        if q.data == "help_sp":
            await q.message.reply_text("Example: /sp https://your-store.myshopify.com")
        else:
            await q.message.reply_text("Use /msp, then upload a TXT file (maximum 20 URLs).")

async def post_init(app: Application):
    init_db()

def main():
    if not BOT_TOKEN:
        raise RuntimeError("Set BOT_TOKEN in Railway Variables.")
    if not ADMIN_IDS:
        raise RuntimeError("Set ADMIN_IDS in Railway Variables (comma-separated Telegram IDs).")
    app = Application.builder().token(BOT_TOKEN).post_init(post_init).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CommandHandler("credits", credits_cmd))
    app.add_handler(CommandHandler("sp", sp_cmd))
    app.add_handler(CommandHandler("msp", msp_cmd))
    app.add_handler(CommandHandler("buy", buy_cmd))
    app.add_handler(CommandHandler("redeem", redeem_cmd))
    app.add_handler(CommandHandler("key", key_cmd))
    app.add_handler(CommandHandler("addcredits", addcredits_cmd))
    app.add_handler(CommandHandler("stats", stats_cmd))
    app.add_handler(CallbackQueryHandler(callback_handler))
    app.add_handler(MessageHandler(filters.Document.ALL, document_handler))
    print("Bot started.")
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    from telegram.ext import CallbackQueryHandler
    main()
