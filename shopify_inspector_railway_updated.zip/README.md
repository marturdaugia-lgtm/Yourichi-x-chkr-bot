# Shopify Store Inspector — Railway deployment

## Important scope
This bot checks basic storefront availability for stores you own or are authorized to manage.
It does **not** validate payment cards, test payment gateways, place orders, or identify approved cards.
Bulk inspection is capped at 20 URLs per TXT file and runs slowly to avoid overloading sites.

## Files
- `bot.py` — Telegram bot
- `requirements.txt` — Python dependencies
- `Procfile` — Railway worker command
- `railway.json` — Railway deployment configuration

## Deploy
1. Create a new GitHub repository and upload these files.
2. In Railway, create a project from that repository.
3. Add these Railway Variables:
   - `BOT_TOKEN` = your Telegram bot token from BotFather
   - `ADMIN_IDS` = optional comma-separated admin IDs; defaults to `8052050530`
   - `FORCE_CHANNELS` = comma-separated channel usernames; defaults to `@harsh_era07,@Dhoni_era_77`
   - `FORCE_CHANNEL_LINKS` = comma-separated join URLs; defaults to the two supplied channel links
4. Add the bot as an administrator in both force-join channels so membership checks work.
5. Deploy. Check Railway logs for `Bot started.`

## Commands
- `/start`, `/help`, `/credits`
- `/sp https://your-store.myshopify.com`
- `/msp` then upload a UTF-8 `.txt` file (maximum 20 URLs)
- `/buy`, `/redeem CODE`
- Admin: `/key DAYS COUNT`, `/addcredits USER_ID AMOUNT`, `/stats`

## Notes
- SQLite is used for the database. Attach a Railway Volume and set `DB_PATH` to a path on that volume (for example `/data/bot.db`) to keep data across redeploys.
- Premium purchases are manual: the admin issues a key with `/key DAYS COUNT` after confirming payment.
- The bot starts with 50 credits for each new user. A single URL inspection costs 1 credit.
- The plan list is informational; it does not process payments.
